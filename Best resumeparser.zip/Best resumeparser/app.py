from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory, jsonify, session
import os
import json
import csv
import io
import re
import sqlalchemy.exc
import nltk
import PyPDF2

# Download NLTK data first to avoid errors
nltk.download('stopwords')
nltk.download('punkt')

import spacy
from pyresparser import ResumeParser
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get("SESSION_SECRET", "your_secret_key")  # Replace with a strong secret key in production
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get("DATABASE_URL", 'sqlite:///site.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Set different options based on the database type to ensure compatibility across environments
if "sqlite" in app.config['SQLALCHEMY_DATABASE_URI']:
    app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
        "pool_recycle": 300,
        "pool_pre_ping": True
    }
else:
    # For PostgreSQL and other databases that support connect_timeout
    app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
        "connect_args": {"connect_timeout": 10}
    }

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

# Make sure all database tables exist
with app.app_context():
    try:
        db.create_all()  # Ensure all tables are created
        app.logger.info("Database tables created successfully")
    except Exception as e:
        app.logger.error(f"Error creating database tables: {str(e)}")

UPLOAD_FOLDER = "uploads"
ALLOWED_EXTENSIONS = {"pdf", "doc", "docx"}
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# Ensure the upload folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Load spaCy model
try:
    nlp = spacy.load("en_core_web_sm")  # We only have the small model installed
except Exception as e:
    print(f"Error loading spaCy model: {e}")
    nlp = None

# Download NLTK models for pyresparser
nltk.download("punkt")
nltk.download("stopwords")

# Define skill points for ranking
skill_points = {
    # Programming Languages
    "Python": 10,
    "Java": 10,
    "C++": 12,
    "C#": 10,
    "JavaScript": 10,
    "TypeScript": 12,
    "Go": 14,
    "Rust": 15,
    "Swift": 12,
    "Kotlin": 12,
    "PHP": 8,
    "R": 10,
    "Scala": 12,
    "Ruby": 10,
    
    # Data Science & Machine Learning
    "Machine Learning": 15,
    "Data Science": 18,
    "Deep Learning": 18,
    "Data Mining": 15,
    "Data Analysis": 12,
    "TensorFlow": 15,
    "PyTorch": 15,
    "Scikit-learn": 14,
    "Pandas": 12,
    "NumPy": 12,
    "NLP": 15,
    "Computer Vision": 15,
    "Reinforcement Learning": 18,
    "Statistical Analysis": 14,
    
    # Web Development
    "HTML": 5,
    "CSS": 5,
    "React": 12,
    "Angular": 12,
    "Vue.js": 10,
    "Node.js": 12,
    "Express": 10,
    "Django": 10,
    "Flask": 10,
    "Bootstrap": 8,
    "Tailwind CSS": 10,
    "jQuery": 8,
    "Redux": 12,
    "GraphQL": 14,
    "REST API": 10,
    
    # Databases
    "SQL": 8,
    "PostgreSQL": 10,
    "MySQL": 10,
    "MongoDB": 10,
    "Firebase": 10,
    "Redis": 12,
    "Elasticsearch": 14,
    "Cassandra": 14,
    "Oracle": 10,
    "SQLite": 8,
    
    # DevOps & Cloud
    "AWS": 15,
    "Azure": 15,
    "Google Cloud": 15,
    "Docker": 12,
    "Kubernetes": 15,
    "Git": 8,
    "GitHub": 8,
    "CI/CD": 10,
    "Jenkins": 10,
    "Terraform": 12,
    "Ansible": 12,
    "DevOps": 15,
    "CloudFormation": 12,
    "Serverless": 14,
    
    # Mobile Development
    "Android": 12,
    "iOS": 12,
    "React Native": 12,
    "Flutter": 12,
    "Xamarin": 10,
    "Mobile Development": 12,
    "App Development": 10,
    
    # Big Data
    "Hadoop": 12,
    "Spark": 14,
    "Kafka": 12,
    "Airflow": 12,
    "Big Data": 15,
    "ETL": 12,
    "Data Warehousing": 12,
    "Data Engineering": 15,
    
    # Soft Skills
    "Communication": 5,
    "Teamwork": 5,
    "Leadership": 8,
    "Project Management": 8,
    "Agile": 5,
    "Scrum": 5,
    "Problem Solving": 10,
    "Critical Thinking": 8,
    
    # Other Technical Skills
    "Cybersecurity": 15,
    "Blockchain": 15,
    "IoT": 12,
    "Microservices": 12,
    "Testing": 10,
    "UI/UX": 10,
    "SEO": 8,
    "Technical Writing": 8
}

# Global candidates list (consider moving to database in production)
candidates = []

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=True)
    date_joined = db.Column(db.DateTime, default=datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class ResumeAnalysis(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    candidate_name = db.Column(db.String(100), nullable=False)
    skills = db.Column(db.Text, nullable=False)  # JSON string of skills
    certificates = db.Column(db.Text, nullable=True)  # JSON string of certificates
    rank = db.Column(db.Integer, nullable=False)
    resume_filename = db.Column(db.String(100), nullable=False)
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)
    
    @property
    def skills_list(self):
        return json.loads(self.skills)
        
    @property
    def certificates_list(self):
        try:
            return json.loads(self.certificates) if self.certificates else []
        except:
            return []

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def calculate_rank(skills):
    return sum(skill_points.get(skill, 0) for skill in skills)

@login_manager.user_loader
def load_user(user_id):
    try:
        return User.query.get(int(user_id))
    except Exception as e:
        # If there's an issue with the transaction, roll it back
        db.session.rollback()
        return None

@app.route("/")
def index():
    return render_template("index.html", now=datetime.now(), error=None)

@app.route("/register", methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        email = request.form.get('email')
        
        # Check if username already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.', 'danger')
            return render_template('register.html', now=datetime.now(), error=None)
        
        if email:
            existing_email = User.query.filter_by(email=email).first()
            if existing_email:
                flash('Email already registered.', 'danger')
                return render_template('register.html', now=datetime.now(), error=None)
        
        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash('Account created successfully! You can now log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html', now=datetime.now(), error=None)

@app.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = request.form.get('remember', 'off') == 'on'
        
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user, remember=remember)
            next_page = request.args.get('next')
            flash('Login successful!', 'success')
            return redirect(next_page or url_for('index'))
        else:
            flash('Login failed. Please check your username and password.', 'danger')
    
    return render_template('login.html', now=datetime.now(), error=None)

@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'success')
    return redirect(url_for('index'))

def extract_skills_from_resume(file_path):
    """
    Extract skills and certificates from resume content using a combination of methods:
    1. Try using pyresparser first (if available)
    2. Use a custom regex-based approach for more thorough extraction
    3. Compare extracted text against our skill_points dictionary
    4. Extract certificates from the resume
    """
    extracted_skills = []
    extracted_certificates = []
    candidate_name = ""
    
    try:
        # Try to use pyresparser first
        resume_data = ResumeParser(file_path).get_extracted_data()
        candidate_name = resume_data.get('name', '')
        skills_from_parser = resume_data.get('skills', [])
        
        if skills_from_parser:
            extracted_skills.extend(skills_from_parser)
    except Exception as e:
        print(f"Pyresparser extraction failed: {str(e)}")
        # Continue with our custom extraction
    
    # Always use our custom approach to maximize skill extraction
    # Get text from PDF with enhanced error handling
    try:
        pdf_text = ""
        with open(file_path, 'rb') as file:
            try:
                pdf_reader = PyPDF2.PdfReader(file)
                for page_num in range(len(pdf_reader.pages)):
                    page = pdf_reader.pages[page_num]
                    page_text = page.extract_text()
                    if page_text:  # Only add if we got actual text
                        pdf_text += page_text
            except Exception as pdf_error:
                print(f"PDF parsing error: {pdf_error}")
                # If PyPDF2 fails, try a simple text extraction as fallback
                file.seek(0)  # Reset file position
                try:
                    raw_bytes = file.read()
                    pdf_text = raw_bytes.decode('utf-8', errors='ignore')
                except:
                    # If everything fails, at least try to get the filename
                    pdf_text = os.path.basename(file_path)
        
        # Only proceed if we have text content
        if not pdf_text.strip():
            print("Warning: Could not extract any text from the PDF")
            # Return minimal result with empty skills
            return {
                'name': os.path.splitext(os.path.basename(file_path))[0].replace("_", " "),
                'skills': [],
                'certificates': []
            }
        
        # Extract skills from the text by looking for patterns and keywords in our skill points
        text_lines = pdf_text.split('\n')
        
        # Extract candidate name with comprehensive multi-method approach
        if not candidate_name:
            # Normalize text for better processing
            pdf_text_normalized = pdf_text.replace('\n', ' ').strip()
            text_lines_clean = [line.strip() for line in text_lines if line.strip()]
            text_lines_lower = [line.lower() for line in text_lines_clean]
            name_found = False
            
            # Method 1: Direct name field extraction
            for i, line in enumerate(text_lines_lower[:20]):  # Check first 20 lines
                # Look for explicit name fields with various formats
                name_patterns = [
                    r'name\s*:\s*([A-Za-z\s\.]+)',
                    r'full\s*name\s*:\s*([A-Za-z\s\.]+)',
                    r'candidate\s*name\s*:\s*([A-Za-z\s\.]+)',
                    r'candidate\s*:\s*([A-Za-z\s\.]+)'
                ]
                
                for pattern in name_patterns:
                    match = re.search(pattern, line, re.IGNORECASE)
                    if match:
                        extracted_name = match.group(1).strip()
                        if len(extracted_name.split()) >= 1:  # At least one word
                            candidate_name = extracted_name.title()
                            name_found = True
                            break
                
                if name_found:
                    break
            
            # Method 2: Look for a name at the very top of the resume
            if not name_found and len(text_lines_clean) > 0:
                top_line = text_lines_clean[0].strip()
                # Check if the first non-empty line looks like a name
                # Criteria: 1-3 words, properly capitalized, no special characters except dots and spaces
                if (len(top_line.split()) <= 3 and 
                    re.match(r'^[A-Za-z\s\.]+$', top_line) and
                    not any(keyword in top_line.lower() for keyword in [
                        "resume", "cv", "curriculum", "vitae", "profile", "summary", "application",
                        "education", "experience", "skills", "qualifications"
                    ])):
                    candidate_name = top_line.title()
                    name_found = True
            
            # Method 3: Look for common Indian name prefixes/suffixes
            if not name_found:
                # Look for lines with common name prefixes or formats
                for i, line in enumerate(text_lines_clean[:10]):
                    # Check for common name prefixes and formats in various cultures
                    prefixes = ["mr.", "mr ", "mrs.", "mrs ", "ms.", "ms ", "miss ", "dr.", "dr ", "prof.", "prof "]
                    # Check if line starts with a prefix
                    for prefix in prefixes:
                        if line.lower().startswith(prefix):
                            # Extract the name (remove the prefix and clean)
                            potential_name = line[len(prefix):].strip()
                            # Verify it looks like a name (1-3 words, properly capitalized)
                            if re.match(r'^[A-Za-z\s\.]+$', potential_name) and len(potential_name.split()) <= 3:
                                candidate_name = potential_name.title()
                                name_found = True
                                break
                    
                    if name_found:
                        break
            
            # Method 4: Context-based name extraction
            if not name_found:
                # Look for phone/email/address sections which often have the name nearby
                contact_indicators = ["email", "phone", "contact", "address", "mobile", "tel", "call"]
                
                for i, line in enumerate(text_lines_lower[:15]):
                    if any(indicator in line for indicator in contact_indicators):
                        # Check the lines before this contact line for potential names
                        for j in range(max(0, i-3), i):
                            potential_name = text_lines_clean[j]
                            # Criteria for a name: 1-3 words, properly capitalized, no special characters
                            if (len(potential_name.split()) <= 3 and 
                                re.match(r'^[A-Za-z\s\.]+$', potential_name) and
                                not any(kw in potential_name.lower() for kw in contact_indicators)):
                                candidate_name = potential_name.title()
                                name_found = True
                                break
                    
                    if name_found:
                        break
            
            # Ultimate fallback: Use filename but with clear indication it's from filename
            if not name_found or not candidate_name:
                file_basename = os.path.splitext(os.path.basename(file_path))[0]
                # Clean up the filename to make it more presentable
                clean_name = " ".join(re.findall(r'[A-Za-z]+', file_basename)).title()
                # Add "Candidate:" prefix to make it clear this is a fallback
                candidate_name = f"Candidate: {clean_name}"
        
        # Enhanced section detection with better boundary recognition
        skill_section = False
        certificate_section = False
        skill_lines = []
        certificate_lines = []
        
        # Keywords to identify different sections - expanded for better matching
        skill_headers = ["skills", "technical skills", "core competencies", "technologies", "expertise", 
                         "proficiencies", "qualifications", "technical expertise", "tools", "languages", 
                         "programming languages", "software", "frameworks"]
        
        cert_headers = ["certification", "certifications", "credentials", "licenses", "professional development", 
                        "certificates", "certified", "accreditation"]
        
        next_section_headers = ["education", "experience", "projects", "work", "professional experience", 
                               "employment", "history", "academic", "interests", "activities", 
                               "achievements", "summary", "objective"]
        
        # First pass: identify sections
        for i, line in enumerate(text_lines):
            line_lower = line.lower().strip()
            
            # More robust section header detection
            if any(re.search(fr'\b{re.escape(header)}\b', line_lower) for header in skill_headers) and not skill_section:
                skill_section = True
                certificate_section = False
                skill_lines.append(line)
                continue
            
            # Look for certification section headers
            if any(re.search(fr'\b{re.escape(header)}\b', line_lower) for header in cert_headers) and not certificate_section:
                certificate_section = True
                skill_section = False
                certificate_lines.append(line)
                continue
            
            # End of current section detection with improved boundary checking
            if (skill_section or certificate_section) and (
                (not line.strip() and i < len(text_lines) - 1 and any(re.search(fr'\b{re.escape(header)}\b', text_lines[i+1].lower()) for header in next_section_headers)) or
                any(re.search(fr'\b{re.escape(header)}\b', line_lower) for header in next_section_headers)
            ):
                skill_section = False
                certificate_section = False
                continue
            
            # Collect lines in the active section
            if skill_section:
                skill_lines.append(line)
            elif certificate_section:
                certificate_lines.append(line)
        
        # Enhanced skill extraction with context awareness and confidence scoring
        # Step 1: Process dedicated skill sections with advanced parsing
        skill_section_confidence = 1.5  # Skills in the skills section get higher confidence
        context_boost = {
            "expert in": 1.3,
            "proficient": 1.3,
            "advanced": 1.3,
            "experienced": 1.2,
            "familiar with": 1.1,
            "knowledge of": 1.1,
            "working with": 1.2,
            "certified": 1.4,
            "skilled": 1.3,
        }
        
        # Combined skill data structure with confidence scores
        skill_candidates_with_confidence = {}  # {skill: confidence_score}
        
        # Process explicit skill section with higher confidence
        for line in skill_lines:
            # Remove common markers for cleaner text
            cleaned_line = re.sub(r'[•·:★▪▫◦‣⁃-]', '', line)
            
            # Split by common separators with more nuanced pattern
            # This handles various formatting styles in resumes
            skill_items = re.split(r'[,|;/]+|\s{3,}|\t+', cleaned_line)
            
            for item in skill_items:
                item = item.strip()
                if not item or len(item) < 2:  # Skip very short terms
                    continue
                
                # Check context modifiers that indicate skill proficiency
                base_confidence = skill_section_confidence
                for context, boost in context_boost.items():
                    if context in item.lower():
                        base_confidence *= boost
                        # Remove the context phrase for cleaner skill extraction
                        item = re.sub(r'\b' + re.escape(context) + r'\b', '', item, flags=re.IGNORECASE).strip()
                
                # Check if exact match in skill_points or with different casing
                item_lower = item.lower()
                matched = False
                
                # First try exact match (highest confidence)
                for known_skill in skill_points.keys():
                    if known_skill.lower() == item_lower:
                        if known_skill not in skill_candidates_with_confidence or \
                           base_confidence > skill_candidates_with_confidence[known_skill]:
                            skill_candidates_with_confidence[known_skill] = base_confidence
                        matched = True
                        break
                
                # If no exact match, try word boundary matching (medium confidence)
                if not matched:
                    for known_skill in skill_points.keys():
                        # Use a regex pattern that looks for word boundaries to avoid partial matches
                        pattern = r'\b' + re.escape(known_skill.lower()) + r'\b'
                        if re.search(pattern, item_lower):
                            if known_skill not in skill_candidates_with_confidence or \
                               base_confidence * 0.9 > skill_candidates_with_confidence[known_skill]:
                                skill_candidates_with_confidence[known_skill] = base_confidence * 0.9
                            matched = True
                            break
                
                # Advanced: Try multi-word skill partial matching (lower confidence)
                # This helps catch "Python programming" when we have "Python" in our skills list
                if not matched and len(item.split()) > 1:
                    for known_skill in skill_points.keys():
                        if len(known_skill.split()) == 1 and known_skill.lower() in item_lower.split():
                            # Only match if it's a distinct word to avoid partial word matches
                            if known_skill not in skill_candidates_with_confidence or \
                               base_confidence * 0.7 > skill_candidates_with_confidence[known_skill]:
                                skill_candidates_with_confidence[known_skill] = base_confidence * 0.7
        
        # Step 2: Process the entire document for skills with context awareness
        # But with much tighter constraints to prevent false positives
        doc_section_confidence = 0.6  # Reduced confidence for skills outside skill sections
        
        # Define contexts that strongly indicate skills vs non-skills
        # This helps distinguish between "Java" as a skill vs "Java" in another context
        strong_skill_contexts = [
            r"technologies\s+(?:include|:|\bred\s+)",
            r"technical\s+(?:skills|expertise)",
            r"(?:proficiency|proficient)\s+in",
            r"expertise\s+in",
            r"experience\s+(?:with|in)",
            r"knowledge\s+of",
            r"familiar\s+with",
            r"worked\s+with",
            r"skill(?:s|set)",
            r"competenc(?:y|ies)",
            r"programming",
            r"software",
            r"develop(?:er|ment)",
            r"engineer(?:ing)?",
            r"tech(?:nical|nologies)?",
        ]
        
        # Define negative contexts that suggest a term is not being used as a skill
        # Expanded to catch more non-skill contexts
        negative_skill_contexts = [
            r"university",
            r"school",
            r"college",
            r"degree in",
            r"graduated",
            r"address",
            r"street",
            r"personal",
            r"references",
            r"hobbies",
            r"born",
            r"nationality",
            r"mail",
            r"phone",
            r"contact",
            r"summary",
            r"objective",
            r"profile",
            r"interests",
            r"activities",
            r"volunteer",
            r"academic",
            r"education",
            r"attend",
            r"studied",
            r"course",
        ]
        
        # Analyze the document but with strict verification for skill mentions outside of skill sections
        # This will dramatically reduce false positives
        for i, line in enumerate(text_lines):
            line_lower = line.lower().strip()
            
            # Skip obvious non-skill sections and very short lines
            if any(pattern in line_lower for pattern in negative_skill_contexts) or len(line_lower) < 4:
                continue
            
            # Only accept skills from the general document if they appear with a strong skill indicator
            # This is a major change to reduce false positives
            has_skill_context = False
            for context in strong_skill_contexts:
                if re.search(context, line_lower, re.IGNORECASE):
                    has_skill_context = True
                    break
            
            # Skip lines without a strong skill indicator context
            if not has_skill_context:
                continue
                
            # Set a higher multiplier for lines with strong skill indicators
            context_multiplier = 1.0
                
            # Within valid skill contexts, look for skill mentions
            for known_skill in skill_points.keys():
                # Use word boundary to ensure we're matching complete words
                pattern = r'\b' + re.escape(known_skill.lower()) + r'\b'
                if re.search(pattern, line_lower):
                    # Check if skill already exists and has higher confidence
                    if known_skill not in skill_candidates_with_confidence or \
                       context_multiplier > skill_candidates_with_confidence[known_skill]:
                        skill_candidates_with_confidence[known_skill] = context_multiplier
        
        # Step 3: Apply a much higher confidence threshold to only accept highly confident skills
        confidence_threshold = 0.95  # Set a higher threshold to reduce false positives
        
        # Filter skills by confidence and sort
        for skill, confidence in sorted(skill_candidates_with_confidence.items(), 
                                       key=lambda x: x[1], reverse=True):
            if confidence >= confidence_threshold:
                extracted_skills.append(skill)
            
        # If we found NO skills, try with a lower threshold but limit to top 3 most confident skills
        if not extracted_skills:
            # Get the top 3 most confident skills
            top_skills = sorted(skill_candidates_with_confidence.items(), 
                               key=lambda x: x[1], reverse=True)[:3]
            
            # Only include skills with confidence above 0.8
            for skill, confidence in top_skills:
                if confidence >= 0.8:
                    extracted_skills.append(skill)
        
        # Enhanced certificate extraction with context awareness and verification
        # Similar to skills, use confidence scoring for certificates
        cert_candidates_with_confidence = {}  # {cert: confidence_score}
        
        # Comprehensive pattern matching for certification formats
        # This handles various ways certificates appear in resumes
        certificate_patterns = [
            # Certification name with explicit certification keyword
            r'([\w\s\-&\.]+\s(?:certification|certificate|certified|license|credential))',
            # Common certification naming patterns like "AWS Certified Solutions Architect"
            r'((?:aws|microsoft|google|oracle|comptia|cisco|pmi|isaca)\s+(?:certified|certification|certificate|credential)[\w\s\-&\.]*)',
            # Credential designations like "PMP®" or "CISSP®"
            r'(\b[A-Z]{2,6}(?:®|\(R\)|™|\(TM\))?(?:\s+certification)?)'
        ]
        
        # Significantly expanded list of common certifications for better matching
        common_certs = {
            # Cloud certifications - higher confidence score
            "aws": 1.3, "amazon web services": 1.3, "azure": 1.3, "google cloud": 1.3, 
            "cloud practitioner": 1.2, "solutions architect": 1.2, "cloud associate": 1.2,
            
            # Project management
            "pmp": 1.3, "project management professional": 1.3, "prince2": 1.3,
            "capm": 1.2, "certified associate in project management": 1.2,
            "scrum": 1.3, "agile": 1.2, "csm": 1.3, "certified scrum master": 1.3,
            "safe": 1.2, "scaled agile framework": 1.2,
            
            # Security
            "cissp": 1.3, "certified information systems security professional": 1.3,
            "security+": 1.3, "ceh": 1.3, "certified ethical hacker": 1.3,
            "cisa": 1.3, "certified information systems auditor": 1.3,
            "cism": 1.3, "certified information security manager": 1.3,
            
            # Networking
            "ccna": 1.3, "cisco certified network associate": 1.3,
            "ccnp": 1.3, "cisco certified network professional": 1.3,
            "network+": 1.3, "juniper": 1.2,
            
            # General IT
            "comptia": 1.3, "a+": 1.3, "linux+": 1.3, "server+": 1.3,
            "mcsa": 1.3, "microsoft certified systems administrator": 1.3,
            "mcse": 1.3, "microsoft certified systems engineer": 1.3,
            "mta": 1.2, "microsoft technology associate": 1.2,
            
            # Database
            "oracle": 1.3, "oca": 1.3, "ocp": 1.3, "oracle certified professional": 1.3,
            "mongodb": 1.3, "cassandra": 1.2,
            
            # Business/Process
            "six sigma": 1.3, "lean six sigma": 1.3, "itil": 1.3, 
            "cobit": 1.3, "togaf": 1.3, "enterprise architecture": 1.2,
            
            # Professional designations
            "cpa": 1.3, "certified public accountant": 1.3,
            "cfa": 1.3, "chartered financial analyst": 1.3,
            "phr": 1.3, "professional in human resources": 1.3,
            
            # Specific technologies
            "salesforce": 1.3, "administrator": 1.1, "developer": 1.1, "consultant": 1.1,
            "servicenow": 1.3, "tableau": 1.3, "power bi": 1.3,
            
            # Development/DevOps
            "kubernetes": 1.3, "docker": 1.3, "terraform": 1.3,
            "jenkins": 1.3, "devops": 1.2, "gitlab": 1.2, "github": 1.2
        }
        
        # Certification section gets higher confidence
        cert_section_confidence = 1.5
        
        # Process certificates in dedicated section first - highest confidence
        for line in certificate_lines:
            line_lower = line.lower()
            
            # Apply all certificate patterns for comprehensive matching
            for pattern in certificate_patterns:
                cert_matches = re.findall(pattern, line, re.IGNORECASE)
                if cert_matches:
                    for cert in cert_matches:
                        cert_clean = cert.strip()
                        if cert_clean:
                            cert_candidates_with_confidence[cert_clean] = cert_section_confidence
                            
            # Also check for common certification keywords
            for cert, confidence_boost in common_certs.items():
                if cert.lower() in line_lower:
                    # Extract the whole line or phrase containing the certification
                    extract = re.search(r'[^.!?]*\b' + re.escape(cert.lower()) + r'\b[^.!?]*', line_lower)
                    if extract:
                        extracted_cert = extract.group(0).strip().capitalize()
                        # Use the higher confidence between section-based and keyword-based
                        cert_candidates_with_confidence[extracted_cert] = max(
                            cert_candidates_with_confidence.get(extracted_cert, 0),
                            cert_section_confidence * confidence_boost
                        )
        
        # Then scan full resume for certificates - but only in clear certification contexts
        # This is much more restrictive to prevent false positives
        doc_cert_confidence = 0.6  # Reduced base confidence
        
        # Define strong certification contexts - MUST have one of these to consider certificates
        cert_indicator_contexts = [
            r"certification",
            r"certificate",
            r"certified",
            r"credential",
            r"accreditation",
            r"license",
            r"qualified",
            r"designation"
        ]
        
        # Skip sections that would never contain certificates
        non_cert_sections = [
            r"university", r"college", r"high school", r"address", r"phone", r"email", r"born", 
            r"nationality", r"marital", r"references", r"hobbies", r"interests", r"objective",
            r"summary", r"profile", r"personal", r"contact", r"social", r"media", r"education",
            r"school", r"course", r"grade", r"class"
        ]
        
        # Only scan certificate and education/qualification sections - more restrictive approach
        in_cert_section = False
        for i, line in enumerate(text_lines):
            line_lower = line.lower().strip()
            
            # Skip lines that are clearly not about certifications and very short lines
            if any(pattern in line_lower for pattern in non_cert_sections) or len(line_lower) < 10:
                continue
            
            # Check if this is a certificate section header
            if any(re.search(r'\b' + re.escape(cert_context) + r'\b', line_lower) for cert_context in cert_indicator_contexts):
                in_cert_section = True
                context_multiplier = 1.0  # Standard confidence for certificate section
            elif line_lower.strip() == '' and i < len(text_lines) - 1:
                # Check if we're exiting a certificate section based on next line content
                next_line = text_lines[i+1].lower().strip()
                if any(section in next_line for section in [
                    "education", "experience", "employment", "projects", "skills", "interests", "references", "summary"
                ]):
                    in_cert_section = False
            
            # Only process lines in certificate sections or lines with explicit certification terms
            has_cert_context = in_cert_section or any(cert_term in line_lower for cert_term in cert_indicator_contexts)
            if not has_cert_context:
                continue
            
            # Apply certificate patterns only on valid certificate lines
            for pattern in certificate_patterns:
                cert_matches = re.findall(pattern, line, re.IGNORECASE)
                if cert_matches:
                    for cert in cert_matches:
                        cert_clean = cert.strip()
                        if cert_clean and len(cert_clean) > 5:  # Require longer matches (5+ chars)
                            # Only update if higher confidence than existing entry
                            if cert_clean not in cert_candidates_with_confidence:
                                cert_candidates_with_confidence[cert_clean] = doc_cert_confidence
            
            # More selective matching for known certifications
            for cert, confidence_boost in common_certs.items():
                if len(cert) >= 3 and re.search(r'\b' + re.escape(cert.lower()) + r'\b', line_lower):
                    # Extract the certificate with more context limited to just the term and nearby words
                    # This is more restrictive than before
                    min_start = max(0, line_lower.find(cert.lower()) - 20)
                    max_end = min(len(line_lower), line_lower.find(cert.lower()) + len(cert) + 20)
                    context_snippet = line_lower[min_start:max_end].strip()
                    
                    # Additionally require certification context terms for common words
                    # This prevents matching common terms that aren't actually certificates
                    if len(cert) <= 5:  # Short terms need stronger verification
                        if not any(cert_term in context_snippet for cert_term in cert_indicator_contexts):
                            continue
                    
                    # Clean up and capitalize properly
                    cert_clean = cert.strip().capitalize()
                    
                    # Only add if not already present with higher confidence
                    if cert_clean not in cert_candidates_with_confidence or \
                       doc_cert_confidence * confidence_boost > cert_candidates_with_confidence[cert_clean]:
                        cert_candidates_with_confidence[cert_clean] = doc_cert_confidence * confidence_boost
        
        # Apply confidence threshold and strict validation to filter out garbage
        cert_confidence_threshold = 0.7
        
        # Patterns that indicate invalid certificates (garbage PDF metadata or document structure)
        invalid_patterns = [
            r'[<>{}[\]\\|^~`]+',     # XML/HTML tags or special characters
            r'^\s*\d+\s*$',          # Just numbers
            r'^\s*[a-z0-9]{1,8}\s*$', # Very short garbage/codes
            r'[=#@%*]',              # Uncommon characters in certificates
            r'^\s*content\s*$',      # Common PDF metadata
            r'^docume',              # Common PDF metadata (document)
            r'^\s*xml\s*$',          # XML reference
            r'^\s*pdf\s*$',          # PDF reference
            r'^\s*word\s*$',         # Word reference
            r'^\s*rels\s*$',         # Relationships XML 
            r'^\s*page\s*$',         # Page references
            r'[^\x00-\x7F]+',        # Non-ASCII characters
            r'^\s*head\s*$',         # Document head section
            r'^\s*body\s*$',         # Document body section
            r'^\s*meta\s*$',         # Meta tags
            r'^\s*conten',           # Content reference (various forms)
            r'tmb+a',                # Common PDF artifact
            r'qo[a-z]d',             # Common PDF artifact
            r'gvt',                  # Common PDF artifact
            r'px[a-z]+',             # Common PDF artifact
            r'gkxm',                 # Common PDF artifact
            r'[a-z]+rj',             # Common PDF artifact
            r'qwl',                  # Common PDF artifact 
            r'^\s*[a-z]{2,5}\s*$',   # Short code-like strings
            r'[+][}]',               # Character combinations from broken PDFs
            r'[&][c]',               # Character combinations from broken PDFs
            r'[#][^]',               # Character combinations from broken PDFs
            r'^[a-z]{1,4}[0-9]+',    # Short alphanumeric codes
            r'\d{2,}',               # Strings with multiple consecutive numbers
            r'[ul][rx][lzn]',        # Common PDF artifact patterns
        ]
        
        # Extra validation function for certificates
        def is_valid_certificate(cert_text):
            # Check minimum length (very short "certificates" are likely garbage)
            if len(cert_text.strip()) < 4:
                return False
                
            # Check for invalid patterns
            for pattern in invalid_patterns:
                if re.search(pattern, cert_text, re.IGNORECASE):
                    return False
            
            # The text should contain at least one letter and have some meaning
            if not re.search(r'[a-zA-Z]{3,}', cert_text):
                return False
                
            # Verify it contains at least one recognizable word (not just random characters)
            common_words = ['certified', 'certificate', 'certification', 'credential', 'license', 
                          'professional', 'associate', 'expert', 'specialist', 'master', 
                          'aws', 'azure', 'google', 'microsoft', 'oracle', 'cisco', 'comptia', 
                          'project', 'management', 'security', 'network', 'programming', 'developer',
                          'administrator']
                          
            if not any(word in cert_text.lower() for word in common_words):
                # Check if it's a known abbreviation (like PMP, CISSP, etc.)
                if not re.match(r'^[A-Z]{2,6}(\+|\s+certification)?$', cert_text):
                    # Not a common abbreviation either
                    return False
            
            return True
        
        # Apply stringent filtering and confidence threshold
        for cert, confidence in sorted(cert_candidates_with_confidence.items(), 
                                     key=lambda x: x[1], reverse=True):
            cert_text = cert.strip()
            if confidence >= cert_confidence_threshold and is_valid_certificate(cert_text):
                extracted_certificates.append(cert_text)
    
    except Exception as e:
        print(f"Custom PDF extraction failed: {str(e)}")
        # Even if extraction fails, return a valid result with the data we have
        # This ensures we don't crash the entire upload process
        return {
            'name': candidate_name or os.path.splitext(os.path.basename(file_path))[0].replace("_", " "),
            'skills': [],
            'certificates': []
        }
    
    # Remove duplicates while preserving order
    unique_skills = []
    for skill in extracted_skills:
        if skill and skill not in unique_skills:  # Add null check
            unique_skills.append(skill)
    
    unique_certificates = []
    for cert in extracted_certificates:
        if cert and cert not in unique_certificates:  # Add null check
            unique_certificates.append(cert)
    
    # Ensure we're returning something meaningful
    result = {
        'name': candidate_name or os.path.splitext(os.path.basename(file_path))[0].replace("_", " "),
        'skills': unique_skills,
        'certificates': unique_certificates
    }
    
    # Log what we're returning for debugging
    print(f"Extracted: {len(unique_skills)} skills, {len(unique_certificates)} certificates for {result['name']}")
    
    return result

@app.route("/upload", methods=["POST"])
def upload_file():
    if not current_user.is_authenticated:
        return jsonify({"error": "Please log in first."}), 401  # Unauthorized access

    if "resume" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["resume"]

    if file.filename == "":
        return jsonify({"error": "No selected file"}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": "Invalid file type. Only PDF, DOC, and DOCX allowed."}), 400

    filename = secure_filename(file.filename)
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(file_path)

    try:
        # Note: We've made the parser more resilient, so we don't need to throw an error if spaCy isn't loaded
        if nlp is None:
            print("Warning: NLP model not available. Falling back to custom extraction only.")
        
        # Extract skills, certificates and name from the resume
        extraction_result = extract_skills_from_resume(file_path)
        candidate_name = extraction_result['name']
        skills = extraction_result['skills']
        certificates = extraction_result.get('certificates', [])
        
        # If no skills were extracted, just leave it as an empty list
        # This respects the actual content of the resume instead of generating random skills
        if not skills:
            skills = []
            flash("No skills were automatically detected in this resume. You can add skills manually in the Manage Skills section.", "info")
            
        # Calculate rank based on selected skills
        rank = calculate_rank(skills)
        
        # If we couldn't extract a name, use the filename
        if not candidate_name or candidate_name == "Unknown Candidate":
            candidate_name = os.path.splitext(filename)[0].replace("_", " ")

        # Store in database
        resume_analysis = ResumeAnalysis(
            user_id=current_user.id,
            candidate_name=candidate_name,
            skills=json.dumps(skills),
            certificates=json.dumps(certificates) if certificates else None,
            rank=rank,
            resume_filename=filename
        )
        db.session.add(resume_analysis)
        db.session.commit()

        # Also maintain the global list for compatibility
        candidate = {
            "name": candidate_name,
            "skills": skills,
            "certificates": certificates,
            "rank": rank,
            "resume": filename,
            "id": resume_analysis.id
        }

        candidates.append(candidate)
        candidates.sort(key=lambda x: x["rank"], reverse=True)

        return jsonify({
            "name": candidate["name"], 
            "skills": skills, 
            "certificates": certificates,
            "rank": rank,
            "id": resume_analysis.id
        })

    except Exception as e:
        print(f"Error in upload_file: {str(e)}")
        # Handle the error gracefully
        db.session.rollback()  # Roll back any failed transactions
        
        # Create a more user-friendly error message
        error_message = "There was an error processing your resume file."
        if "EOF marker not found" in str(e):
            error_message = "The PDF file appears to be corrupted. Please upload a different file."
        elif "Could not read" in str(e):
            error_message = "Could not read the file contents. Please ensure it's a valid PDF file."
        elif "codec can't decode" in str(e):
            error_message = "The file contains unsupported characters. Please save as a standard PDF and try again."
            
        # Flash the error message for the user
        flash(error_message, "danger")
        
        # Return a minimal result with empty skills rather than failing
        # This allows the user to continue using the app even if parsing failed
        filename_base = os.path.splitext(filename)[0].replace("_", " ").title()
        
        # Add "Candidate" prefix to make it clear this is a fallback name from filename
        candidate_name = f"Candidate: {filename_base}"
        
        # Store in database with minimal info
        resume_analysis = ResumeAnalysis(
            user_id=current_user.id,
            candidate_name=candidate_name,
            skills=json.dumps([]),
            certificates=None,
            rank=0,
            resume_filename=filename
        )
        db.session.add(resume_analysis)
        db.session.commit()
        
        return jsonify({
            "name": candidate_name, 
            "skills": [], 
            "certificates": [],
            "rank": 0,
            "id": resume_analysis.id,
            "warning": "File uploaded but no skills could be extracted automatically. You can add skills manually."
        })

@app.route("/ranking")
@login_required
def ranking():
    # Get resumes from database
    analyses = ResumeAnalysis.query.filter_by(user_id=current_user.id).order_by(ResumeAnalysis.rank.desc()).all()
    
    # Convert to dict format that the template expects
    candidates_db = [
        {
            "id": analysis.id,
            "name": analysis.candidate_name,
            "skills": json.loads(analysis.skills),
            "certificates": json.loads(analysis.certificates) if analysis.certificates else [],
            "rank": analysis.rank,
            "resume": analysis.resume_filename,
            "date": analysis.upload_date.strftime("%Y-%m-%d")
        }
        for analysis in analyses
    ]
    
    # Get skill counts for chart
    all_skills = []
    for candidate in candidates_db:
        all_skills.extend(candidate["skills"])
    
    skill_counts = {}
    for skill in all_skills:
        if skill in skill_counts:
            skill_counts[skill] += 1
        else:
            skill_counts[skill] = 1
    
    top_skills = sorted(skill_counts.items(), key=lambda x: x[1], reverse=True)[:10]
    skill_labels = [skill[0] for skill in top_skills]
    skill_data = [skill[1] for skill in top_skills]
    
    return render_template(
        "ranking.html", 
        candidates=candidates_db, 
        skill_labels=json.dumps(skill_labels),
        skill_data=json.dumps(skill_data),
        now=datetime.now(),
        error=None
    )

@app.route("/resume/<filename>")
@login_required
def serve_resume(filename):
    # Find the resume in database to verify ownership
    resume = ResumeAnalysis.query.filter_by(resume_filename=filename, user_id=current_user.id).first()
    
    # If not found, don't authorize access
    if not resume:
        flash("You don't have permission to view this resume.", "danger")
        return redirect(url_for("ranking"))
        
    # Add cache control headers for better performance
    response = send_from_directory(app.config["UPLOAD_FOLDER"], filename)
    response.headers["Cache-Control"] = "public, max-age=3600"  # Cache for 1 hour
    return response

@app.route("/about")
def about():
    return render_template("about.html", now=datetime.now(), error=None)

@app.route("/dashboard")
@login_required
def dashboard():
    # Get resumes from database
    analyses = ResumeAnalysis.query.filter_by(user_id=current_user.id).order_by(ResumeAnalysis.upload_date.desc()).all()
    
    # Calculate stats
    total_resumes = len(analyses)
    average_rank = sum(a.rank for a in analyses) / total_resumes if total_resumes > 0 else 0
    top_candidate = max(analyses, key=lambda x: x.rank) if analyses else None
    
    # Get all skills and their counts
    all_skills = []
    for analysis in analyses:
        all_skills.extend(json.loads(analysis.skills))
    
    skill_counts = {}
    for skill in all_skills:
        if skill in skill_counts:
            skill_counts[skill] += 1
        else:
            skill_counts[skill] = 1
    
    top_skills = sorted(skill_counts.items(), key=lambda x: x[1], reverse=True)[:10]
    
    # Get monthly data for trend chart
    monthly_data = {}
    for analysis in analyses:
        month = analysis.upload_date.strftime('%b %Y')
        if month in monthly_data:
            monthly_data[month]['count'] += 1
            monthly_data[month]['avg_rank'] = (monthly_data[month]['avg_rank'] * (monthly_data[month]['count'] - 1) + analysis.rank) / monthly_data[month]['count']
        else:
            monthly_data[month] = {'count': 1, 'avg_rank': analysis.rank}
    
    months = list(monthly_data.keys())
    resume_counts = [monthly_data[m]['count'] for m in months]
    avg_ranks = [monthly_data[m]['avg_rank'] for m in months]
    
    # Get most recent analyses for the dashboard
    recent_analyses = analyses[:5]
    
    return render_template(
        "dashboard.html",
        total_resumes=total_resumes,
        average_rank=round(average_rank, 2),
        top_candidate=top_candidate,
        top_skills=top_skills,
        months=json.dumps(months),
        resume_counts=json.dumps(resume_counts),
        avg_ranks=json.dumps(avg_ranks),
        recent_analyses=recent_analyses,
        now=datetime.now(),
        error=None
    )

@app.route("/inputskill", methods=["GET", "POST"])
@login_required
def input_skill():
    if request.method == "POST":
        # Handle both standard form submission and JSON data
        skills_data = request.form.get("skills", "[]")
        try:
            # Try to parse as JSON
            selected_skills = json.loads(skills_data)
            if isinstance(selected_skills, str):
                selected_skills = [selected_skills]
        except:
            # If not valid JSON, handle as regular form data
            selected_skills = [skill.strip() for skill in request.form.getlist("skills") if skill.strip()]
        
        # Get candidates from database
        analyses = ResumeAnalysis.query.filter_by(user_id=current_user.id).all()
        
        filtered_candidates = []
        for analysis in analyses:
            candidate_skills = json.loads(analysis.skills)
            candidate_skills_lower = [s.lower() for s in candidate_skills]
            
            # More lenient matching - check if any of the selected skills match
            # This will show more results
            if len(selected_skills) == 0 or any(skill.lower() in candidate_skills_lower for skill in selected_skills):
                filtered_candidates.append({
                    "id": analysis.id,
                    "name": analysis.candidate_name,
                    "skills": candidate_skills,
                    "certificates": json.loads(analysis.certificates) if analysis.certificates else [],
                    "rank": analysis.rank,
                    "resume": analysis.resume_filename,
                    "date": analysis.upload_date.strftime("%Y-%m-%d")
                })
        
        filtered_candidates.sort(key=lambda x: x["rank"], reverse=True)
        
        # Get all available skills for the autocomplete
        all_skills = set()
        for analysis in analyses:
            all_skills.update(json.loads(analysis.skills))
        available_skills = sorted(list(all_skills))
        
        # Get skill counts for chart
        all_skills_filtered = []
        for candidate in filtered_candidates:
            all_skills_filtered.extend(candidate["skills"])
        
        skill_counts = {}
        for skill in all_skills_filtered:
            if skill in skill_counts:
                skill_counts[skill] += 1
            else:
                skill_counts[skill] = 1
        
        top_skills = sorted(skill_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        skill_labels = [skill[0] for skill in top_skills]
        skill_data = [skill[1] for skill in top_skills]
        
        return render_template(
            "ranking.html", 
            candidates=filtered_candidates, 
            selected_skills=selected_skills,
            available_skills=available_skills,
            skill_labels=json.dumps(skill_labels),
            skill_data=json.dumps(skill_data),
            now=datetime.now(),
            error=None
        )
    
    # Get all available skills for the autocomplete
    analyses = ResumeAnalysis.query.filter_by(user_id=current_user.id).all()
    all_skills = set()
    for analysis in analyses:
        all_skills.update(json.loads(analysis.skills))
    available_skills = sorted(list(all_skills))
    
    return render_template("inputskill.html", available_skills=available_skills, now=datetime.now(), error=None)

@app.route("/delete_resume/<int:resume_id>", methods=["POST"])
@login_required
def delete_resume(resume_id):
    try:
        # Get resume using one query with no_load to improve performance
        resume = ResumeAnalysis.query.filter_by(id=resume_id, user_id=current_user.id).first()
        
        if not resume:
            # Either resume doesn't exist or doesn't belong to user
            flash("Resume not found or you don't have permission to delete it.", "danger")
            return redirect(url_for("ranking"))
        
        # Remember filename for file deletion
        filename = resume.resume_filename
        
        # Delete database entry first - most important part
        db.session.delete(resume)
        db.session.commit()
        
        # Then try to delete file (non-critical operation) asynchronously
        # We don't want the file deletion to block the response
        try:
            file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            if os.path.exists(file_path):
                os.remove(file_path)
        except Exception:
            # Simply log the error but don't disrupt the user experience
            print(f"Warning: Could not delete file {filename}")
            pass
        
        flash("Resume deleted successfully.", "success")
        return redirect(url_for("ranking"))
        
    except Exception as e:
        db.session.rollback()
        flash(f"Error deleting resume: {str(e)}", "danger")
        return redirect(url_for("ranking"))

@app.route("/delete_selected", methods=["POST"])
@login_required
def delete_selected():
    try:
        # Get all resume IDs from the form
        resume_ids = request.form.getlist('resume_ids')
        
        if not resume_ids:
            flash("No resumes selected for deletion.", "warning")
            return redirect(url_for("ranking"))
        
        # Convert to integers
        resume_ids = [int(id) for id in resume_ids]
        
        # Get all resumes that belong to this user with the given IDs
        resumes = ResumeAnalysis.query.filter(
            ResumeAnalysis.id.in_(resume_ids),
            ResumeAnalysis.user_id == current_user.id
        ).all()
        
        if not resumes:
            flash("No matching resumes found or you don't have permission to delete them.", "danger")
            return redirect(url_for("ranking"))
        
        # Remember filenames for file deletion
        filenames = [resume.resume_filename for resume in resumes]
        
        # Delete database entries first
        for resume in resumes:
            db.session.delete(resume)
        
        db.session.commit()
        
        # Then try to delete files (non-critical operation)
        for filename in filenames:
            try:
                file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
                if os.path.exists(file_path):
                    os.remove(file_path)
            except Exception:
                # Log the error but continue with remaining files
                print(f"Warning: Could not delete file {filename}")
                continue
        
        flash(f"Successfully deleted {len(resumes)} resume(s).", "success")
        return redirect(url_for("ranking"))
        
    except Exception as e:
        db.session.rollback()
        flash(f"Error deleting resumes: {str(e)}", "danger")
        return redirect(url_for("ranking"))

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        # Update email
        email = request.form.get("email")
        if email and email != current_user.email:
            # Check if email is already used
            existing_email = User.query.filter_by(email=email).first()
            if existing_email and existing_email.id != current_user.id:
                flash("Email is already in use by another account.", "danger")
            else:
                current_user.email = email
                flash("Email updated successfully.", "success")
        
        # Change password if provided
        current_password = request.form.get("current_password")
        new_password = request.form.get("new_password")
        confirm_password = request.form.get("confirm_password")
        
        if current_password and new_password and confirm_password:
            if not current_user.check_password(current_password):
                flash("Current password is incorrect.", "danger")
            elif new_password != confirm_password:
                flash("New passwords don't match.", "danger")
            else:
                current_user.set_password(new_password)
                flash("Password updated successfully.", "success")
        
        db.session.commit()
        return redirect(url_for("profile"))
    
    # Get user's resume count
    user_resumes_count = ResumeAnalysis.query.filter_by(user_id=current_user.id).count()
    
    return render_template("profile.html", now=datetime.now(), user_resumes_count=user_resumes_count, error=None)

@app.route("/compare", methods=["GET", "POST"])
@login_required
def compare():
    if request.method == "POST":
        resume_ids = request.form.getlist("resume_ids")
        if len(resume_ids) < 2:
            flash("Please select at least two resumes to compare.", "warning")
            return redirect(url_for("ranking"))
        
        # Get the selected resumes
        selected_resumes = []
        for resume_id in resume_ids:
            resume = ResumeAnalysis.query.get(resume_id)
            if resume and resume.user_id == current_user.id:
                selected_resumes.append({
                    "id": resume.id,
                    "name": resume.candidate_name,
                    "skills": json.loads(resume.skills),
                    "certificates": json.loads(resume.certificates) if resume.certificates else [],
                    "rank": resume.rank,
                    "resume": resume.resume_filename
                })
        
        # Collect all unique skills across the selected resumes
        all_skills = set()
        all_certificates = set()
        for resume in selected_resumes:
            all_skills.update(resume["skills"])
            all_certificates.update(resume.get("certificates", []))
        
        # Create comparison data for skills
        skills_comparison_data = []
        for skill in sorted(all_skills):
            skill_data = {"skill": skill}
            
            for resume in selected_resumes:
                has_skill = skill in resume["skills"]
                skill_data[f"resume_{resume['id']}"] = has_skill
            
            skills_comparison_data.append(skill_data)
        
        # Create comparison data for certificates
        certificates_comparison_data = []
        for certificate in sorted(all_certificates):
            cert_data = {"certificate": certificate}
            
            for resume in selected_resumes:
                has_certificate = certificate in resume.get("certificates", [])
                cert_data[f"resume_{resume['id']}"] = has_certificate
            
            certificates_comparison_data.append(cert_data)
        
        return render_template(
            "compare.html", 
            resumes=selected_resumes, 
            skills_comparison_data=skills_comparison_data,
            certificates_comparison_data=certificates_comparison_data,
            now=datetime.now(),
            error=None
        )
    
    # If GET, redirect to ranking page
    return redirect(url_for("ranking"))

@app.route("/export_csv", methods=["POST"])
@login_required
def export_csv():
    # Get candidates from database or from filtered list in session
    resume_ids = request.form.getlist("resume_ids")
    
    if resume_ids:
        analyses = ResumeAnalysis.query.filter(ResumeAnalysis.id.in_(resume_ids)).all()
    else:
        analyses = ResumeAnalysis.query.filter_by(user_id=current_user.id).all()
    
    candidates_list = [
        {
            "Name": analysis.candidate_name,
            "Skills": ", ".join(json.loads(analysis.skills)),
            "Certificates": ", ".join(json.loads(analysis.certificates) if analysis.certificates else []),
            "Rank Score": analysis.rank,
            "Date Added": analysis.upload_date.strftime("%Y-%m-%d")
        }
        for analysis in analyses
    ]
    
    # Create CSV in memory
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=["Name", "Skills", "Certificates", "Rank Score", "Date Added"])
    writer.writeheader()
    writer.writerows(candidates_list)
    
    # Return the CSV as a response
    response = app.response_class(
        response=output.getvalue(),
        mimetype='text/csv',
        headers={"Content-Disposition": "attachment;filename=candidate_ranking.csv"}
    )
    
    return response

@app.route("/skill_scores")
@login_required
def skill_scores():
    # Return the skill points dictionary for the frontend
    return jsonify(skill_points)

@app.route("/manage_skills", methods=["GET", "POST"])
@login_required
def manage_skills():
    error_message = None
    success_message = None
    
    if request.method == "POST":
        action = request.form.get("action")
        skill_name = request.form.get("skill_name", "").strip()
        
        if action == "add" and skill_name:
            # Add a new skill
            skill_score = int(request.form.get("skill_score", 10))
            if skill_score < 1 or skill_score > 20:
                skill_score = 10  # Default if out of range
                
            if skill_name in skill_points:
                error_message = f"Skill '{skill_name}' already exists with score {skill_points[skill_name]}."
            else:
                skill_points[skill_name] = skill_score
                success_message = f"Skill '{skill_name}' added successfully with score {skill_score}."
                
        elif action == "remove" and skill_name:
            # Remove a skill
            if skill_name in skill_points:
                del skill_points[skill_name]
                success_message = f"Skill '{skill_name}' removed successfully."
            else:
                error_message = f"Skill '{skill_name}' not found in the database."
    
    # Sort skills by name for display
    skills_with_scores = sorted(skill_points.items(), key=lambda x: x[0].lower())
    
    return render_template(
        "manage_skills.html",
        skills_with_scores=skills_with_scores,
        error_message=error_message,
        success_message=success_message,
        now=datetime.now(),
        error=None
    )

@app.errorhandler(404)
def page_not_found(e):
    db.session.rollback()  # Roll back any pending transactions
    app.logger.error(f"404 error: {request.path}")
    return render_template('error.html', error="Page not found", now=datetime.now()), 404

@app.errorhandler(500)
def server_error(e):
    db.session.rollback()  # Roll back any pending transactions
    app.logger.error(f"500 error: {str(e)}")
    return render_template('error.html', error="Server error. Please try again later.", now=datetime.now()), 500

# Add error handler for SQLAlchemy errors
@app.errorhandler(sqlalchemy.exc.SQLAlchemyError)
def handle_db_error(e):
    try:
        db.session.rollback()  # Roll back any pending transactions
        app.logger.error(f"Database error: {str(e)}")
        # Try to ping the database to see if it's still available
        db.session.execute("SELECT 1")
        db.session.commit()
        app.logger.info("Database connection re-established after error")
    except Exception as ping_error:
        app.logger.error(f"Failed to re-establish database connection: {str(ping_error)}")
    
    return render_template('error.html', error="Database error. Please try again later.", now=datetime.now()), 500

# Add a catch-all route for undefined routes
@app.route('/<path:undefined_route>')
def undefined_route_handler(undefined_route):
    app.logger.warning(f"Attempted to access undefined route: {undefined_route}")
    return render_template('error.html', error="Page not found", now=datetime.now()), 404

with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
