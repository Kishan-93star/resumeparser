document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const menuBtn = document.querySelector('.navbar-menu-btn');
    const mobileMenu = document.querySelector('.navbar-mobile');
    
    if (menuBtn && mobileMenu) {
        menuBtn.addEventListener('click', function() {
            mobileMenu.classList.toggle('show-mobile-menu');
        });
    }
    
    // File upload preview
    const fileInput = document.getElementById('file-input');
    const fileName = document.querySelector('.file-name');
    
    if (fileInput && fileName) {
        fileInput.addEventListener('change', function() {
            if (fileInput.files.length > 0) {
                fileName.textContent = fileInput.files[0].name;
                fileName.style.display = 'block';
            } else {
                fileName.style.display = 'none';
            }
        });
    }
    
    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        });
    });
    
    // Auto dismiss alerts
    const alerts = document.querySelectorAll('.alert-dismissible');
    
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.classList.add('fade-out');
            setTimeout(() => {
                alert.remove();
            }, 500);
        }, 5000);
    });
    
    // File upload form with loader
    const uploadForm = document.getElementById('uploadForm');
    const loadingOverlay = document.getElementById('loading-overlay');
    const resultContainer = document.getElementById('result');
    
    if (uploadForm && loadingOverlay) {
        uploadForm.addEventListener('submit', function(event) {
            event.preventDefault();
            
            if (!fileInput.files.length) {
                showMessage('Please select a file to upload', 'danger');
                return;
            }
            
            const formData = new FormData();
            formData.append('resume', fileInput.files[0]);
            
            loadingOverlay.style.display = 'flex';
            
            fetch('/upload', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                loadingOverlay.style.display = 'none';
                
                if (data.error) {
                    showMessage(data.error, 'danger');
                } else {
                    // Display success message
                    showMessage('Resume successfully processed!', 'success');
                    
                    // Display extracted skills
                    if (resultContainer) {
                        resultContainer.innerHTML = `
                            <div class="card fade-in">
                                <div class="card-body">
                                    <h3 class="card-title">Extracted Information</h3>
                                    <p><strong>Name:</strong> ${data.name}</p>
                                    <p><strong>Rank Score:</strong> ${data.rank}</p>
                                    <div>
                                        <strong>Skills:</strong>
                                        <div class="skills-container">
                                            ${data.skills.map(skill => `<span class="badge badge-primary">${skill}</span>`).join('')}
                                        </div>
                                    </div>
                                    <div class="mt-4">
                                        <a href="/ranking" class="btn btn-primary">View Rankings</a>
                                    </div>
                                </div>
                            </div>
                        `;
                    }
                }
            })
            .catch(error => {
                loadingOverlay.style.display = 'none';
                showMessage('Error processing file: ' + error.message, 'danger');
            });
        });
    }
    
    // Function to show messages
    function showMessage(message, type) {
        const alertContainer = document.getElementById('alert-container');
        if (alertContainer) {
            const alert = document.createElement('div');
            alert.className = `alert alert-${type} alert-dismissible fade-in`;
            alert.innerHTML = `
                ${message}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            `;
            
            alertContainer.appendChild(alert);
            
            // Auto dismiss after 5 seconds
            setTimeout(() => {
                alert.classList.add('fade-out');
                setTimeout(() => {
                    alert.remove();
                }, 500);
            }, 5000);
            
            // Manual dismiss
            const closeBtn = alert.querySelector('.close');
            if (closeBtn) {
                closeBtn.addEventListener('click', function() {
                    alert.classList.add('fade-out');
                    setTimeout(() => {
                        alert.remove();
                    }, 500);
                });
            }
        }
    }
    
    // Tooltip initialization
    const tooltips = document.querySelectorAll('[data-toggle="tooltip"]');
    tooltips.forEach(tooltip => {
        tooltip.addEventListener('mouseover', function() {
            const tooltipText = document.createElement('div');
            tooltipText.className = 'tooltip-text';
            tooltipText.textContent = tooltip.getAttribute('data-title');
            tooltip.appendChild(tooltipText);
        });
        
        tooltip.addEventListener('mouseout', function() {
            const tooltipText = tooltip.querySelector('.tooltip-text');
            if (tooltipText) {
                tooltipText.remove();
            }
        });
    });
    
    // Initialize skill tags input (for the filter form)
    const skillInput = document.getElementById('skill-input');
    const skillsContainer = document.getElementById('selected-skills');
    const skillsHiddenInput = document.getElementById('skills-hidden');
    
    if (skillInput && skillsContainer && skillsHiddenInput) {
        const availableSkills = JSON.parse(skillInput.getAttribute('data-available-skills') || '[]');
        const selectedSkills = [];
        
        // Initialize autocomplete
        let currentFocus;
        
        skillInput.addEventListener('input', function() {
            closeAllLists();
            if (!this.value) return false;
            currentFocus = -1;
            
            const autocompleteList = document.createElement('div');
            autocompleteList.setAttribute('id', 'autocomplete-list');
            autocompleteList.setAttribute('class', 'autocomplete-items');
            this.parentNode.appendChild(autocompleteList);
            
            const val = this.value.toLowerCase();
            
            for (let i = 0; i < availableSkills.length; i++) {
                if (availableSkills[i].toLowerCase().indexOf(val) !== -1) {
                    const item = document.createElement('div');
                    item.innerHTML = availableSkills[i].replace(new RegExp(val, 'gi'), match => `<strong>${match}</strong>`);
                    item.innerHTML += `<input type="hidden" value="${availableSkills[i]}">`;
                    
                    item.addEventListener('click', function() {
                        const value = this.getElementsByTagName('input')[0].value;
                        addSkill(value);
                        closeAllLists();
                    });
                    
                    autocompleteList.appendChild(item);
                }
            }
        });
        
        skillInput.addEventListener('keydown', function(e) {
            let x = document.getElementById('autocomplete-list');
            if (x) x = x.getElementsByTagName('div');
            
            if (e.key === 'ArrowDown') {
                currentFocus++;
                addActive(x);
            } else if (e.key === 'ArrowUp') {
                currentFocus--;
                addActive(x);
            } else if (e.key === 'Enter') {
                e.preventDefault();
                if (currentFocus > -1 && x) {
                    x[currentFocus].click();
                } else if (this.value.trim()) {
                    addSkill(this.value.trim());
                }
            }
        });
        
        function addActive(x) {
            if (!x) return false;
            removeActive(x);
            if (currentFocus >= x.length) currentFocus = 0;
            if (currentFocus < 0) currentFocus = x.length - 1;
            x[currentFocus].classList.add('autocomplete-active');
        }
        
        function removeActive(x) {
            for (let i = 0; i < x.length; i++) {
                x[i].classList.remove('autocomplete-active');
            }
        }
        
        function closeAllLists(elmnt) {
            const x = document.getElementsByClassName('autocomplete-items');
            for (let i = 0; i < x.length; i++) {
                if (elmnt !== x[i] && elmnt !== skillInput) {
                    x[i].parentNode.removeChild(x[i]);
                }
            }
        }
        
        document.addEventListener('click', function(e) {
            closeAllLists(e.target);
        });
        
        function addSkill(skill) {
            if (!skill || selectedSkills.includes(skill)) return;
            
            selectedSkills.push(skill);
            updateSkillsContainer();
            skillInput.value = '';
            updateHiddenInput();
        }
        
        function removeSkill(skill) {
            const index = selectedSkills.indexOf(skill);
            if (index !== -1) {
                selectedSkills.splice(index, 1);
                updateSkillsContainer();
                updateHiddenInput();
            }
        }
        
        function updateSkillsContainer() {
            skillsContainer.innerHTML = '';
            
            selectedSkills.forEach(skill => {
                const badge = document.createElement('span');
                badge.className = 'badge badge-primary';
                badge.innerHTML = `${skill} <i class="fas fa-times"></i>`;
                badge.querySelector('i').addEventListener('click', function() {
                    removeSkill(skill);
                });
                
                skillsContainer.appendChild(badge);
            });
        }
        
        function updateHiddenInput() {
            skillsHiddenInput.value = JSON.stringify(selectedSkills);
        }
        
        // Initialize with any existing selected skills
        const existingSkills = JSON.parse(skillsHiddenInput.value || '[]');
        existingSkills.forEach(skill => addSkill(skill));
    }
    
    // Initialize comparison checkboxes
    const compareCheckboxes = document.querySelectorAll('.compare-checkbox');
    const compareBtn = document.getElementById('compare-btn');
    
    if (compareCheckboxes.length > 0 && compareBtn) {
        compareCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const checkedBoxes = document.querySelectorAll('.compare-checkbox:checked');
                compareBtn.disabled = checkedBoxes.length < 2;
            });
        });
    }
});
